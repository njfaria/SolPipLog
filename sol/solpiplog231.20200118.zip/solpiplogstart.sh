#!/bin/bash

cd /home/pi/sol
./solpiplog
exit 0
