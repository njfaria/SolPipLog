#!/bin/bash
sudo mkdir /home/pi/.config/autostart
sudo cp solpiplog.desktop /home/pi/.config/autostart
sudo cp solpiplog.rules /etc/udev/rules.d