YOU DONT NEED TO EXECUTE IF YOU DOWNLOADED THE IMAGE
This file shoud be in a folder named sol in your /home/pi folder
open terminal window with CTRL-ALT-T and type :
./setup.sh
